/* =========================================================================
   Salvataggio dei progressi.
   - ScormStore: se il corso è aperto da un LMS (SCORM 1.2), progressi e
     stato vengono salvati nella piattaforma.
   - LocalStore: altrimenti, localStorage del browser (come nella versione
     non SCORM).
   Entrambi hanno la stessa interfaccia (load, save, clear, finish, ok, kind),
   quindi player.js non cambia.
   ========================================================================= */
(function () {
  "use strict";

  /* ---------- Salvataggio locale ---------- */
  function LocalStore(courseId) {
    this.key = "player:" + courseId;
    this.kind = "local";
    this.ok = false;
    try {
      var probe = "__player_probe__";
      window.localStorage.setItem(probe, "1");
      window.localStorage.removeItem(probe);
      this.ok = true;
    } catch (e) {
      this.ok = false; // file:// in alcuni browser, navigazione privata, cookie bloccati
    }
  }

  LocalStore.prototype.load = function () {
    if (!this.ok) return null;
    try { return JSON.parse(window.localStorage.getItem(this.key) || "null"); }
    catch (e) { return null; }
  };

  LocalStore.prototype.save = function (data) {
    if (!this.ok) return false;
    try { window.localStorage.setItem(this.key, JSON.stringify(data)); return true; }
    catch (e) { return false; }
  };

  LocalStore.prototype.clear = function () {
    if (!this.ok) return;
    try { window.localStorage.removeItem(this.key); } catch (e) { /* niente */ }
  };

  LocalStore.prototype.finish = function () { /* nulla da chiudere in locale */ };

  /* ---------- Salvataggio SCORM 1.2 ---------- */

  /** Cerca l'oggetto API dell'LMS nelle finestre genitrici e in quella che ha aperto il corso. */
  function findApi() {
    function scan(w) {
      for (var i = 0; w && i < 10; i++) {
        try { if (w.API) return w.API; } catch (e) { return null; } // finestra di altra origine
        if (w.parent === w) break;
        w = w.parent;
      }
      return null;
    }
    var api = scan(window);
    if (!api && window.opener) api = scan(window.opener);
    return api;
  }

  var SUSPEND_MAX = 4096; // limite di cmi.suspend_data in SCORM 1.2

  function ScormStore(api) {
    this.api = api;
    this.kind = "scorm";
    this.start = Date.now();
    this.closed = false;
    this.final = null; // "passed" una volta raggiunto non torna indietro
    this.ok = String(api.LMSInitialize("")) === "true";
    if (!this.ok) return;
    var prev = this.get("cmi.core.lesson_status");
    if (prev === "passed" || prev === "completed") this.final = prev;
    var self = this;
    // "unload" arriva dopo "pagehide", quando player.js ha già salvato.
    window.addEventListener("unload", function () { self.close(); });
  }

  ScormStore.prototype.get = function (k) { return String(this.api.LMSGetValue(k) || ""); };
  ScormStore.prototype.set = function (k, v) { return String(this.api.LMSSetValue(k, String(v))) === "true"; };

  /** Stato SCORM ricavato dalle lezioni: superato, non superato o in corso. */
  ScormStore.prototype.statusFrom = function (data) {
    if (this.final) return this.final;
    var lessons = (window.COURSE && window.COURSE.lessons) || [];
    var status = (data && data.status) || {};
    var hasQuiz = false, failed = false, all = lessons.length > 0;
    lessons.forEach(function (l) {
      if (l.type === "quiz") { hasQuiz = true; if (status[l.id] === "failed") failed = true; }
      if (status[l.id] !== "done") all = false;
    });
    if (all) return (this.final = hasQuiz ? "passed" : "completed");
    return failed ? "failed" : "incomplete";
  };

  ScormStore.prototype.load = function () {
    if (!this.ok) return null;
    try { return JSON.parse(this.get("cmi.suspend_data") || "null"); }
    catch (e) { return null; }
  };

  ScormStore.prototype.save = function (data) {
    if (!this.ok || this.closed) return false;
    var json = JSON.stringify(data);
    if (json.length > SUSPEND_MAX) {
      // Si tengono solo i progressi, senza le preferenze dell'interfaccia.
      json = JSON.stringify({ v: data.v, status: data.status, location: data.location, time: data.time });
    }
    var ok = this.set("cmi.suspend_data", json);
    if (data.location) this.set("cmi.core.lesson_location", data.location);
    this.set("cmi.core.lesson_status", this.statusFrom(data));
    this.set("cmi.core.exit", "suspend"); // permette di riprendere il corso
    this.api.LMSCommit("");
    return ok;
  };

  ScormStore.prototype.clear = function () {
    if (!this.ok || this.closed) return;
    this.set("cmi.suspend_data", "");
    this.api.LMSCommit("");
  };

  /** Uscita dal Player verso la copertina: salva il tempo ma lascia aperta la sessione. */
  ScormStore.prototype.finish = function () {
    if (!this.ok || this.closed) return;
    this.set("cmi.core.session_time", scormTime(Date.now() - this.start));
    this.api.LMSCommit("");
  };

  /** Chiusura della finestra: chiude la sessione con l'LMS. */
  ScormStore.prototype.close = function () {
    if (!this.ok || this.closed) return;
    this.finish();
    this.closed = true;
    this.api.LMSFinish("");
  };

  /** Durata in formato SCORM 1.2: HHHH:MM:SS. */
  function scormTime(ms) {
    var s = Math.floor(ms / 1000);
    function p(n, w) { return String(n).padStart(w, "0"); }
    return p(Math.floor(s / 3600), 4) + ":" + p(Math.floor(s / 60) % 60, 2) + ":" + p(s % 60, 2);
  }

  window.PlayerStorage = {
    create: function (courseId) {
      var api = findApi();
      if (api) {
        var store = new ScormStore(api);
        if (store.ok) return store;
      }
      return new LocalStore(courseId);
    }
  };
})();
